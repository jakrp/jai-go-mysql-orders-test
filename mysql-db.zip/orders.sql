-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 02, 2022 at 07:45 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trading_orders`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `ID` int(10) UNSIGNED NOT NULL,
  `Instrutment` varchar(255) DEFAULT NULL,
  `Ordertype` varchar(255) DEFAULT NULL,
  `Buysell` varchar(255) DEFAULT NULL,
  `Quantity` varchar(255) DEFAULT NULL,
  `Price` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ID`, `Instrutment`, `Ordertype`, `Buysell`, `Quantity`, `Price`, `Status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 'GBPUSD', 'LMT', 'BUY', '200', '1.3444', 'pending', '2022-10-02 18:01:52', '2022-10-02 18:01:52', NULL),
(4, 'GBPUSD', 'LMT', 'BUY', '10', '1.1222', 'pending', '2022-10-02 19:09:40', '2022-10-02 19:09:40', NULL),
(5, 'GBPUSD', 'LMT', 'SELL', '10000', '0.9885', 'pending', '2022-10-02 19:48:27', '2022-10-02 19:48:27', NULL),
(6, 'GBPUSD', 'LMT', 'SELL', '4300', '1.5243', 'pending', '2022-10-02 20:01:58', '2022-10-02 20:01:58', NULL),
(7, 'GBPUSD', 'LMT', 'BUY', '60', '1.1222', 'pending', '2022-10-02 20:08:00', '2022-10-02 20:08:00', NULL),
(8, 'GBPUSD', 'MKT', 'SELL', '880', '1.0600', 'pending', '2022-10-03 03:47:30', '2022-10-03 03:47:30', NULL),
(9, 'GBPUSD', 'MKT', 'BUY', '4000', '1.0600', 'pending', '2022-10-03 03:48:05', '2022-10-03 03:48:05', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `idx_orders_deleted_at` (`deleted_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
